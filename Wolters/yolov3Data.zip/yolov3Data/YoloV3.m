% Get YOLO detector
preTrainedDetector = yolov3ObjectDetector('tiny-yolov3-coco');

% Define the groundtruth boxes for image coco2
coco2GTboxesXYXY = [103 238 228 317;
                    283 219 373 294;
                    352 228 439 294;
                    447 227 520 285;
                    469 224 553 283;
                    575 218 632 262];
coco2GTboxesXYWH = coco2GTboxesXYXY;
coco2GTboxesXYWH(:, 3) = coco2GTboxesXYXY(:, 3) - coco2GTboxesXYXY(:, 1);
coco2GTboxesXYWH(:, 4) = coco2GTboxesXYXY(:, 4) - coco2GTboxesXYXY(:, 2);

% Read image and detect objects
testImage = imread(".\coco2.jpg");
[predictedBboxes,predictedScores,predictedLabels] = detect(preTrainedDetector, testImage, SelectStrongest=false, Threshold=0.3); % Enabling SelectStrongest applies non-maximum suppression.

groundTruthVisualization =    insertObjectAnnotation(testImage,'rectangle', coco2GTboxesXYWH, "zebra");
predictedScoreVisualization = insertObjectAnnotation(testImage,'rectangle',predictedBboxes,predictedScores);
predictedLabelVisualization = insertObjectAnnotation(testImage,'rectangle',predictedBboxes,predictedLabels);

% Visualize
f = figure(1);
f.Position = [0,0, 1920, 1080];
subplot(1,2,1)
imshow(groundTruthVisualization)
title('Ground truth labels')
subplot(1,2,2)
imshow(predictedScoreVisualization) % Feel free to replace with predictedLabelVisualization
title('YOLO predicted boxes with scores')

% Your code for the assignment here: